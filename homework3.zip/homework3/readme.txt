//readMe


for the part c

run 
gcc -o container container.c

./container 6 1 2 3 ps aux

argument[1]: number of namespace
arguement[2]: cpi_pct
arguement[3]: mem_limit
arguement[4]: numbe_levels
arguement[5]: cmd
arguement[6]: arguements